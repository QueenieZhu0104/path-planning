# Path V78 部署前检查清单

## 当前验证状态
- Chromium 浏览器交互检查：26/26 通过（使用内存加载的 HTML，不是线上网页）。
- 后端模拟接口测试：12 项通过；没有调用真实 AI，也没有对大学网站发起实时抓取。
- 8 个内嵌 JavaScript 块全部通过 `node --check`。
- 内置数据检查：31 所大学、390 个 University × programme 路线、48 条活动记录；内置 validator 无错误。

## Cloudflare Pages 部署前必须确认
1. 确认要部署到哪个现有 Cloudflare Pages 项目；不要直接沿用或改动旧项目名，除非已确认。
2. 在 Cloudflare Pages 项目环境变量中私下配置 `OPENAI_API_KEY`（以及可选 `OPENAI_MODEL`），或配置 Workers AI 的 `AI` binding。不要把密钥写进 HTML、公开仓库、截图或聊天。
3. 为 `/api/syllabus` 和 `/api/university-info` 设置 Cloudflare rate limiting / abuse controls。两个 API 会触发来源抓取和 AI 处理；域名 allowlist 本身不等于请求频率限制。
4. 安装依赖并运行 `npm test`。
5. 从项目根目录部署 `public/`，确保同一项目根目录里的 `functions/api/` 被 Cloudflare Pages Functions 识别：

```bash
npm install
npm test
npx wrangler pages secret put OPENAI_API_KEY --project-name YOUR_EXISTING_PAGES_PROJECT
npx wrangler pages deploy ./public --project-name YOUR_EXISTING_PAGES_PROJECT
```

6. 部署后必须在真实网址验证：首页硬刷新、Onboarding、Explore、大学、专业、Syllabus 四个标签、官方信息 API、Plan、Compare、Reminders、Reset，并检查 API 失败时的降级提示。

## 已知限制
- 当前包尚未部署；不要把本地测试结果当成线上测试。
- AI 接口测试使用模拟响应；真实 AI 服务需要用户在部署平台配置。
- 当前数据覆盖范围有限：内置审计显示 15/390 条路线匹配到已核验活动证据，375 条没有路线专属的已核验活动证据。没有匹配结果不代表不存在机会。
- `wrangler.toml` 的 `name` 保留了旧配置值，等待确认现有 Cloudflare Pages 项目后再决定是否修改；部署命令需显式使用确认过的项目名。
