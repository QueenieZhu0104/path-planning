# Path V78 — QA and Test Report

## Summary

- **Browser interaction checks:** 26 passed, 0 failed.
- **Backend contract tests:** 12 checks passed across two test files; provider calls and official-source fetches were mocked.
- **Inline JavaScript syntax:** all 8 script blocks passed `node --check`.
- **Built-in data validator:** no remaining issues reported after the validator was corrected to recognise runtime-exposed handlers and route-specific activity records.
- **Catalogue audit:** 31 university records, 390 University × programme routes, 48 canonical activity records; `PATH_FINAL_AUDIT.issues` is empty.

## Browser interaction checks performed

The page was loaded into Chromium through Playwright using the HTML content in an isolated test page. The test did not contact a deployed site.

1. Initial app render and V78 version labels.
2. Chinese onboarding language selection.
3. Nickname step and onboarding interest/region selections.
4. Corrected selection-limit guidance (4 interest areas and 4 regions, matching the implemented controls).
5. Finish onboarding and open the global university directory.
6. Open the National University of Singapore detail page.
7. Open Data Science & Economics and render the Syllabus section.
8. Select all four Syllabus tabs.
9. Simulate an unconfigured AI provider and confirm the Syllabus guide falls back gracefully.
10. Mock a successful official-information response and confirm supported facts, unverified items, source links, and retrieval time render.
11. Confirm the official-source resolver is available to the official-information action.
12. Save two University × Major routes and open Compare.
13. Create a reminder.
14. Reset and confirm the UI returns to language onboarding and in-memory route/activity/reminder state is cleared.
15. Run the built-in data validator and catalogue integrity summary.
16. Check horizontal overflow at 320, 390, 768, 1024 and 1440 CSS-pixel widths.
17. Confirm no uncaught page errors or browser console errors during the tested paths.

## Bugs fixed in V78

- The official-information button called `chooseSource` from outside the scope where it was declared, causing a `ReferenceError`. The Syllabus module now exposes a narrow source-resolver function, and the button uses it. The successful mocked official-information UI path was tested after the fix.
- The user-facing app label said V75 even though the page title and package were V77. The visible release label and Syllabus metadata now identify V78.
- The Chinese and Traditional Chinese onboarding hint said 5 interest areas and 3 regions, while the controls actually allowed 4 and 4. The hint now matches the implemented limits.
- The built-in data validator falsely flagged functions assigned to `window` and activities added through route-specific evidence. Its checks now recognise runtime-exposed handlers and route-resolved activity records; the current validation result is empty.
- Updated the test/report version references to V78.

## Backend contract tests

`npm test` passed both test files:

- Syllabus endpoint: 7 checks covering provider-not-configured fallback, disallowed source domains, structured OpenAI response handling, redirect rejection, Workers AI binding, malformed model output and unsupported method.
- University-info endpoint: 5 checks covering missing provider, disallowed domains, source-to-AI structured output and source metadata, redirect rejection and unsupported method.

All provider and official-source HTTP interactions in these tests were mocked. No live OpenAI/Workers AI call was made.

## Data coverage and limits

- 31 universities and 390 University × programme entries are present in the current catalogue.
- 48 canonical activity records are present in the built-in audit summary.
- The current audit identifies 15 routes with matched verified activity evidence and 375 without route-specific verified activity evidence. Absence of a matched activity is not evidence that no opportunity exists; users should check the linked official sources.
- 47 of 48 activity records are marked as having an official page reviewed in the existing audit data; the review dates are retained as stored and were not refreshed as part of this code QA.
- The 31 university catalogue URLs matched the university-info endpoint's HTTPS host allowlist.
- Catalogue/source presence does not prove that every programme, deadline, eligibility rule or current admissions cycle has been freshly verified.

## Not yet verified — do not call these passed

- Live reads from university websites; websites may block server-side requests or return general index pages.
- Live AI response quality, latency, cost and provider configuration.
- Production deployment, Cloudflare Pages routing, production secrets/bindings, rate limiting/abuse controls and hard refresh on the deployed origin.
- Native-origin browser storage persistence across reloads. The Reset interaction was checked in the isolated in-memory browser session; it was not represented as a production-origin persistence test.
- Full end-to-end activity submission or external application flows.

## Deployment gate

Do not deploy the API endpoints publicly until the existing Cloudflare Pages project name is confirmed, the selected AI provider is configured privately, and rate limiting/abuse controls are set for both `/api/syllabus` and `/api/university-info`. Never place provider keys in `public/index.html`, a public repository, or a chat message.
