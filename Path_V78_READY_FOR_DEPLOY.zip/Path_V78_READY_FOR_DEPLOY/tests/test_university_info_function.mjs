import assert from 'node:assert/strict';
import { onRequestPost, onRequestGet } from '../functions/api/university-info.js';
const html = '<html><body><h1>Undergraduate admissions</h1><p>Applicants must consult the current official programme page for application requirements. The university publishes admissions information and academic programme descriptions on this official page. This text is long enough for the reader to test source extraction without claiming a specific score, fee, deadline or requirement that is not in the evidence. Applicants should check the relevant official page for the current cycle before making application decisions.</p></body></html>';
const model = {overview:'已读取学校官方页面；具体申请要求只列出页面明确支持的事实。',verifiedFacts:[{label:'页面主题',value:'本科招生信息',sourceUrl:'https://admissions.hku.hk/',quoteOrEvidence:'页面标题为本科招生。'}],notVerified:['当前申请截止日期未从提供的页面文本中核实。'],nextSteps:['打开官方专业页面确认最新申请周期。'],overallStatus:'partial-source'};
const oldFetch=globalThis.fetch; let calls=[];
function mock(handler){calls=[];globalThis.fetch=async(input,init={})=>{const url=typeof input==='string'?input:input.url;calls.push({url,init});return handler(url,init);};}
const req=(body)=>new Request('https://path.test/api/university-info',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
const ctx=(request,env={})=>({request,env});
try {
 mock(()=>{throw Error('should not fetch without AI')});
 let r=await onRequestPost(ctx(req({university:'HKU',sourceUrls:['https://admissions.hku.hk/']}),{})); assert.equal(r.status,503);
 mock(()=>{throw Error('blocked URL must not fetch')});
 r=await onRequestPost(ctx(req({university:'X',sourceUrls:['https://evil.example/']}),{OPENAI_API_KEY:'test'})); assert.equal(r.status,400); assert.equal(calls.length,0);
 mock((url,init)=>{if(url==='https://admissions.hku.hk/')return new Response(html,{status:200,headers:{'content-type':'text/html'}});if(url==='https://api.openai.com/v1/responses'){const b=JSON.parse(init.body);assert.match(b.input,/Applicants must consult/);return new Response(JSON.stringify({output_text:JSON.stringify(model)}),{status:200,headers:{'content-type':'application/json'}})}throw Error('unexpected '+url)});
 r=await onRequestPost(ctx(req({university:'HKU',question:'Current undergraduate admissions',lang:'zh',sourceUrls:['https://admissions.hku.hk/']}),{OPENAI_API_KEY:'test'}));assert.equal(r.status,200);const p=await r.json();assert.equal(p.info.verifiedFacts.length,1);assert.equal(p.sources[0].url,'https://admissions.hku.hk/');assert.match(r.headers.get('cache-control'),/max-age=300/);assert.equal(calls.length,2);
 mock((url)=>url==='https://admissions.hku.hk/'?new Response('',{status:302,headers:{location:'https://evil.example/redirect'}}):Promise.reject(Error('redirect target requested')));
 r=await onRequestPost(ctx(req({university:'HKU',sourceUrls:['https://admissions.hku.hk/']}),{OPENAI_API_KEY:'test'}));assert.equal(r.status,400);assert.equal(calls.length,1);
 assert.equal(onRequestGet().status,405);
 console.log('PASS: missing provider returns 503');console.log('PASS: arbitrary domains are blocked');console.log('PASS: official source → AI JSON → traceable source metadata');console.log('PASS: redirects to unapproved domains are blocked');console.log('PASS: unsupported GET method returns 405');console.log('All university-info contract tests passed (mocked; no live provider calls).');
} finally {globalThis.fetch=oldFetch;}
