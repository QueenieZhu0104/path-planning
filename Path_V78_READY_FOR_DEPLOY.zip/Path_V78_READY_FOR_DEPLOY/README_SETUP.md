# Path V78 — Programme Syllabus + Official University Information API

## What the page does

Every one of the 390 programme entries in the current 31-university directory opens a plain-language Syllabus card. Each card has four tabs:

1. **Course map** — common concepts and methods a student may encounter.
2. **Practice and skills** — example assignments/projects (these are ideas, not official university assignments).
3. **Possible careers** — illustrative directions, not job guarantees.
4. **Who it may suit** — interests, challenges, and differences from adjacent subjects.

The offline guide uses 28 discipline-specific frameworks. The programme name and official university catalogue link are shown on each card. This is a student-friendly subject guide, not the university's official course list; it does not claim that every example is a required module at the named university.

## How the source-based AI version works

The **AI 整理该校版本 / AI-summarise this university's source** button posts the university name, programme label, language and official source URL to `POST /api/syllabus`.

The Pages Function then:

- allows only HTTPS source URLs on the official domains used by the Path university directory;
- fetches readable HTML, blocks redirects to unrelated domains, strips common page chrome, and limits source text sent to the model;
- prompts the model to create a plain-language synthesis rather than copy the official source wording;
- separates source-supported statements from general disciplinary background, and warns when the source is only a catalogue/index;
- returns structured content for the four page tabs.

The status label tells the user whether the official page text appears to mention the programme title or whether it is only a general university catalogue/index. A name match is only a diagnostic, not proof that every curriculum detail has been verified.

Generated guides are cached in browser storage for the current device. The Path reset clears this Syllabus cache along with the other `path_` data.

## AI provider setup (optional, required for live generation)

The single HTML file intentionally does **not** contain an API secret. In static/file preview, the AI button displays a clear fallback message and the built-in Syllabus remains available.

Choose one provider for the Pages Function:

### OpenAI API

1. Copy `.dev.vars.example` to `.dev.vars` and replace the placeholder with your own API key. Keep `.dev.vars` private and out of Git.
2. The function reads `OPENAI_API_KEY` and optionally `OPENAI_MODEL` (default: `gpt-5-mini`).
3. A real model request may incur charges. Do not paste the key into `public/index.html`.

### Cloudflare Workers AI

Bind Workers AI using the binding name `AI` in the Cloudflare Pages project settings. The function uses `@cf/meta/llama-3.1-8b-instruct` by default, configurable via `WORKERS_AI_MODEL`. Cloudflare documents local binding setup and notes that requests use the account's AI service and can incur usage charges: https://developers.cloudflare.com/pages/functions/bindings/.

## Local development

```bash
npm install
npm run dev
```

The project uses Cloudflare Pages Functions routing from `functions/api/syllabus.js`. For local Workers AI development, use a configured binding or `npx wrangler pages dev ./public --ai=AI` as supported by the Pages Functions runtime.

## Automated backend contract tests (no real AI calls)

```bash
npm test
```

The included test file mocks university-page fetches and AI provider responses. It checks unconfigured-provider handling, domain allowlisting, redirect rejection, OpenAI response handling, Cloudflare AI binding handling, malformed model output, and HTTP method handling. These are backend contract tests, **not** a live model-quality test.

## Deployment notes

To run the AI function, deploy the **full project folder** with Cloudflare Pages Functions support. Cloudflare documents that Pages Functions can be deployed through Git integration or Wrangler and that dashboard Direct Upload is not supported for Functions: https://developers.cloudflare.com/pages/functions/get-started/.

For a Wrangler deploy, configure the secret on your existing Pages project and deploy the `public` output folder from this project:

```bash
npx wrangler pages secret put OPENAI_API_KEY --project-name YOUR_PAGES_PROJECT
npx wrangler pages deploy ./public --project-name YOUR_PAGES_PROJECT
```

If using Workers AI instead of OpenAI, add the `AI` binding in Pages project settings, then deploy again. Before exposing the endpoint publicly, configure Cloudflare rate limiting/abuse controls on `/api/syllabus`; the source-domain allowlist does not by itself prevent repeated paid requests.

## Test boundary

The current audit report is included as `TEST_REPORT.md`. No real provider credentials were supplied and no deployment was made, so the live OpenAI/Workers AI model response and live server-side reads from all 31 university websites have not been claimed as tested.

## Source-grounded university information API (V77 groundwork)

A second endpoint, `POST /api/university-info`, supports source-grounded questions about a university. Supply `university`, an optional `question`, `lang` (`zh`, `tw`, or `en`), and 1–3 `sourceUrls` from the allowlisted official university domains. The endpoint reads those pages at request time, sends only extracted page text to the configured AI provider, and returns `verifiedFacts` with source URLs, `notVerified` items, next steps, and retrieval timestamps. It deliberately does not invent deadlines, fees, test scores, or requirements missing from the supplied pages. Responses advertise a short five-minute HTTP cache with stale-while-revalidate; this is request-time retrieval with a short cache, not a background crawler or a promise that every page is current.

Example request body:

```json
{
  "university": "The University of Hong Kong",
  "question": "Summarise current undergraduate admissions requirements for this programme",
  "lang": "en",
  "sourceUrls": ["https://admissions.hku.hk/"]
}
```

Important limitations: the client must supply the relevant official programme/admissions URLs; the endpoint does not discover every university page automatically. A successful fetch means the page was readable at retrieval time, not that the university itself updated it today. Review source URLs and expand the domain allowlist deliberately when adding universities. Live AI/API behaviour still requires deploying the full project and configuring an API secret or Cloudflare AI binding. Do not place secrets in `public/` or commit `.dev.vars`.

## V77 feature retained in V78 — Front-end official university information panel

The programme-detail Syllabus card now includes **查询大学官方最新信息 / Check official university information**. Clicking it sends the selected university, programme, language and the currently configured official URL to `POST /api/university-info`. The UI renders source-supported facts, unverified items, next checks, the retrieval timestamp, and clickable official source URLs. The source is fetched on demand; it does not run a hidden crawler or background polling loop.

### What “current” means

- The API fetches the supplied official URL when the user requests a check, unless an intermediary/browser cache serves a still-fresh response (the API advertises a five-minute cache).
- Retrieval time means when Path fetched the page, not when the university last updated it.
- The programme page's configured URL may be a general admissions/catalogue page. Users should open the cited page and check programme-specific/current-cycle pages for critical details.
- The AI key or Cloudflare `AI` binding must be configured on the deployed Pages Functions environment. A static HTML preview cannot run the backend endpoint.

### Scheduled monitoring status

V77 is request-time retrieval, not scheduled monitoring. Reliable scheduled change detection needs a maintained source registry (specific official programme/admissions URLs), persistent snapshot/hash storage, retry/rate-limit rules, and an alert destination. Those should be configured deliberately rather than pretending that a cron job over generic university homepages guarantees current admissions data. A future scheduled monitor can use GitHub Actions + a versioned source registry and store change reports as workflow artifacts, or Cloudflare Cron Triggers + durable storage for a deployed service.


## V78 QA notes

V78 fixes the front-end official-information action so it uses the Syllabus source resolver exposed from the Syllabus module; V77 called a closure-local `chooseSource` from outside its scope, causing a `ReferenceError` when the official-information button was clicked. The visible product version is now V78. The Cloudflare Pages project name and production deployment settings must be confirmed against the user's existing account before deployment; do not deploy until the AI provider secret/binding and abuse controls are configured.
